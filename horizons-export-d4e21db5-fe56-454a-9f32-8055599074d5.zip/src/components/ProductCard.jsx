
import React from "react";
import { Link } from "react-router-dom";
import { Card, CardContent, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ShoppingCart } from "lucide-react";
import { formatPrice } from "@/lib/utils";
import { useCart } from "@/context/CartContext";
import { motion } from "framer-motion";

const ProductCard = ({ product }) => {
  const { addToCart } = useCart();

  const handleAddToCart = (e) => {
    e.preventDefault();
    e.stopPropagation();
    addToCart(product, 1);
  };

  const displayImage = product.images && product.images.length > 0 ? product.images[0] : "https://via.placeholder.com/400";

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
      whileHover={{ y: -5 }}
    >
      <Card className="product-card overflow-hidden h-full flex flex-col">
        <Link to={`/product/${product.id}`} className="flex-1 flex flex-col">
          <div className="relative aspect-square overflow-hidden">
            <img
              src={displayImage}
              alt={product.name}
              className="object-cover w-full h-full transition-transform duration-300 hover:scale-105"
            />
            {product.stock <= 3 && product.stock > 0 && (
              <div className="absolute top-2 right-2 bg-yellow-500 text-white text-xs px-2 py-1 rounded-md">
                ¡Últimas unidades!
              </div>
            )}
            {product.stock === 0 && (
              <div className="absolute inset-0 bg-black/60 flex items-center justify-center">
                <span className="text-white font-bold text-lg">Agotado</span>
              </div>
            )}
          </div>
          <CardContent className="p-4 flex-1">
            <h3 className="font-semibold text-lg line-clamp-1">{product.name}</h3>
            <p className="text-muted-foreground text-sm line-clamp-2 mt-1">
              {product.description}
            </p>
            <div className="mt-2 font-bold text-lg">{formatPrice(product.price)}</div>
          </CardContent>
          <CardFooter className="p-4 pt-0">
            <Button 
              className="w-full gap-2" 
              onClick={handleAddToCart}
              disabled={product.stock === 0}
            >
              <ShoppingCart className="h-4 w-4" />
              Añadir al carrito
            </Button>
          </CardFooter>
        </Link>
      </Card>
    </motion.div>
  );
};

export default ProductCard;
