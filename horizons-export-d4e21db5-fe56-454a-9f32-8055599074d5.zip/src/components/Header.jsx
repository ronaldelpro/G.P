
import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { 
  NavigationMenu,
  NavigationMenuList,
  NavigationMenuItem,
  NavigationMenuLink
} from "@/components/ui/navigation-menu";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { 
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger
} from "@/components/ui/dropdown-menu";
import { ShoppingCart, User, LogOut, Search, Menu, X } from "lucide-react";
import { cn } from "@/lib/utils";
import { useAuth } from "@/context/AuthContext";
import { useCart } from "@/context/CartContext";
import { motion } from "framer-motion";

const Header = () => {
  const { currentUser, logout } = useAuth();
  const { getCartCount } = useCart();
  const navigate = useNavigate();
  const [searchQuery, setSearchQuery] = useState("");
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const handleSearch = (e) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      navigate(`/search?q=${encodeURIComponent(searchQuery)}`);
      setSearchQuery("");
    }
  };

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  const cartCount = getCartCount();

  return (
    <header className="sticky top-0 z-40 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container flex h-16 items-center justify-between">
        <div className="flex items-center gap-2">
          <Button variant="ghost" size="icon" className="md:hidden" onClick={toggleMenu}>
            {isMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </Button>
          
          <Link to="/" className="flex items-center gap-2">
            <motion.div 
              initial={{ scale: 0.8 }}
              animate={{ scale: 1 }}
              transition={{ duration: 0.5 }}
              className="font-bold text-xl text-primary"
            >
              G.P.
            </motion.div>
          </Link>
        </div>

        <NavigationMenu className="hidden md:flex">
          <NavigationMenuList>
            <NavigationMenuItem>
              <Link to="/category/camisetas" className="nav-link px-4 py-2 text-sm font-medium">
                Camisetas
              </Link>
            </NavigationMenuItem>
            <NavigationMenuItem>
              <Link to="/category/pantalonetas" className="nav-link px-4 py-2 text-sm font-medium">
                Pantalonetas
              </Link>
            </NavigationMenuItem>
            <NavigationMenuItem>
              <Link to="/category/zapatos" className="nav-link px-4 py-2 text-sm font-medium">
                Zapatos
              </Link>
            </NavigationMenuItem>
            <NavigationMenuItem>
              <Link to="/category/medias" className="nav-link px-4 py-2 text-sm font-medium">
                Medias
              </Link>
            </NavigationMenuItem>
          </NavigationMenuList>
        </NavigationMenu>

        <div className="flex items-center gap-4">
          <form onSubmit={handleSearch} className="hidden md:flex relative">
            <Input
              type="search"
              placeholder="Buscar productos..."
              className="w-[200px] lg:w-[300px]"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
            <Button type="submit" size="icon" variant="ghost" className="absolute right-0 top-0">
              <Search className="h-4 w-4" />
            </Button>
          </form>

          <Link to="/cart">
            <Button variant="ghost" size="icon" className="relative">
              <ShoppingCart className="h-5 w-5" />
              {cartCount > 0 && (
                <span className="absolute -top-1 -right-1 bg-primary text-primary-foreground text-xs font-bold rounded-full h-5 w-5 flex items-center justify-center">
                  {cartCount}
                </span>
              )}
            </Button>
          </Link>

          {currentUser ? (
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon" className="rounded-full">
                  <Avatar className="h-8 w-8">
                    <AvatarFallback className="bg-primary text-primary-foreground">
                      {currentUser.name.charAt(0).toUpperCase()}
                    </AvatarFallback>
                  </Avatar>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuLabel>Mi cuenta</DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={() => navigate("/profile")}>
                  <User className="mr-2 h-4 w-4" />
                  Perfil
                </DropdownMenuItem>
                {currentUser.role === "admin" && (
                  <DropdownMenuItem onClick={() => navigate("/admin")}>
                    Panel de administración
                  </DropdownMenuItem>
                )}
                <DropdownMenuItem onClick={() => navigate("/my-products")}>
                  Mis productos
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => navigate("/orders")}>
                  Mis pedidos
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={logout}>
                  <LogOut className="mr-2 h-4 w-4" />
                  Cerrar sesión
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          ) : (
            <Button variant="outline" size="sm" onClick={() => navigate("/login")}>
              Iniciar sesión
            </Button>
          )}
        </div>
      </div>

      {/* Mobile menu */}
      {isMenuOpen && (
        <motion.div 
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -10 }}
          className="md:hidden border-t"
        >
          <div className="container py-4 flex flex-col gap-4">
            <form onSubmit={handleSearch} className="flex relative">
              <Input
                type="search"
                placeholder="Buscar productos..."
                className="w-full"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
              <Button type="submit" size="icon" variant="ghost" className="absolute right-0 top-0">
                <Search className="h-4 w-4" />
              </Button>
            </form>
            
            <div className="flex flex-col">
              <Link 
                to="/category/camisetas" 
                className="py-2 px-4 hover:bg-accent rounded-md"
                onClick={() => setIsMenuOpen(false)}
              >
                Camisetas
              </Link>
              <Link 
                to="/category/pantalonetas" 
                className="py-2 px-4 hover:bg-accent rounded-md"
                onClick={() => setIsMenuOpen(false)}
              >
                Pantalonetas
              </Link>
              <Link 
                to="/category/zapatos" 
                className="py-2 px-4 hover:bg-accent rounded-md"
                onClick={() => setIsMenuOpen(false)}
              >
                Zapatos
              </Link>
              <Link 
                to="/category/medias" 
                className="py-2 px-4 hover:bg-accent rounded-md"
                onClick={() => setIsMenuOpen(false)}
              >
                Medias
              </Link>
            </div>
          </div>
        </motion.div>
      )}
    </header>
  );
};

export default Header;
