
import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/components/ui/use-toast";
import { PlusCircle, Trash2 } from "lucide-react";

const ProductForm = ({ initialData = {}, onSubmit, buttonText = "Guardar producto" }) => {
  const [formData, setFormData] = useState({
    name: initialData.name || "",
    description: initialData.description || "",
    price: initialData.price || "",
    category: initialData.category || "",
    images: initialData.images || [""],
    stock: initialData.stock || 1,
  });
  
  const [errors, setErrors] = useState({});
  const { toast } = useToast();
  
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
    if (errors[name]) {
      setErrors(prev => ({ ...prev, [name]: null }));
    }
  };

  const handleImageChange = (index, value) => {
    const newImages = [...formData.images];
    newImages[index] = value;
    setFormData(prev => ({ ...prev, images: newImages }));
    if (errors.images && errors.images[index]) {
      const newImageErrors = [...(errors.images || [])];
      newImageErrors[index] = null;
      setErrors(prev => ({ ...prev, images: newImageErrors.some(e => e) ? newImageErrors : null }));
    }
  };

  const addImageField = () => {
    setFormData(prev => ({ ...prev, images: [...prev.images, ""] }));
  };

  const removeImageField = (index) => {
    if (formData.images.length > 1) {
      const newImages = formData.images.filter((_, i) => i !== index);
      setFormData(prev => ({ ...prev, images: newImages }));
    } else {
      toast({
        title: "No se puede eliminar",
        description: "Debe haber al menos una imagen.",
        variant: "destructive",
      });
    }
  };
  
  const handleSelectChange = (value, name) => {
    setFormData(prev => ({ ...prev, [name]: value }));
    if (errors[name]) {
      setErrors(prev => ({ ...prev, [name]: null }));
    }
  };
  
  const validateForm = () => {
    const newErrors = {};
    
    if (!formData.name.trim()) newErrors.name = "El nombre es obligatorio";
    if (!formData.description.trim()) newErrors.description = "La descripción es obligatoria";
    if (!formData.price || isNaN(Number(formData.price)) || Number(formData.price) <= 0) {
      newErrors.price = "El precio debe ser un número mayor que cero";
    }
    if (!formData.category) newErrors.category = "La categoría es obligatoria";
    
    const imageErrors = formData.images.map(img => img.trim() ? null : "La URL de la imagen es obligatoria");
    if (imageErrors.some(e => e)) newErrors.images = imageErrors;
    if (!formData.images.some(img => img.trim())) newErrors.images = ["Debe agregar al menos una URL de imagen válida."];


    if (!formData.stock || isNaN(Number(formData.stock)) || Number(formData.stock) < 0) {
      newErrors.stock = "El stock debe ser un número mayor o igual a cero";
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };
  
  const handleSubmit = (e) => {
    e.preventDefault();
    
    if (validateForm()) {
      const processedData = {
        ...formData,
        price: Number(formData.price),
        stock: Number(formData.stock),
        images: formData.images.filter(img => img.trim() !== "") // Filtrar URLs vacías
      };
      
      try {
        onSubmit(processedData);
      } catch (error) {
        toast({
          title: "Error",
          description: error.message || "Ha ocurrido un error al guardar el producto",
          variant: "destructive",
        });
      }
    } else {
      toast({
        title: "Error de validación",
        description: "Por favor, corrige los errores en el formulario",
        variant: "destructive",
      });
    }
  };
  
  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="space-y-2">
        <Label htmlFor="name">Nombre del producto</Label>
        <Input
          id="name"
          name="name"
          value={formData.name}
          onChange={handleChange}
          className={errors.name ? "border-destructive" : ""}
        />
        {errors.name && <p className="text-destructive text-sm">{errors.name}</p>}
      </div>
      
      <div className="space-y-2">
        <Label htmlFor="description">Descripción</Label>
        <Textarea
          id="description"
          name="description"
          value={formData.description}
          onChange={handleChange}
          className={errors.description ? "border-destructive" : ""}
          rows={4}
        />
        {errors.description && <p className="text-destructive text-sm">{errors.description}</p>}
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="price">Precio</Label>
          <Input
            id="price"
            name="price"
            type="number"
            value={formData.price}
            onChange={handleChange}
            className={errors.price ? "border-destructive" : ""}
            min="0"
            step="1000"
          />
          {errors.price && <p className="text-destructive text-sm">{errors.price}</p>}
        </div>
        
        <div className="space-y-2">
          <Label htmlFor="category">Categoría</Label>
          <Select
            value={formData.category}
            onValueChange={(value) => handleSelectChange(value, "category")}
          >
            <SelectTrigger className={errors.category ? "border-destructive" : ""}>
              <SelectValue placeholder="Selecciona una categoría" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="camisetas">Camisetas</SelectItem>
              <SelectItem value="pantalonetas">Pantalonetas</SelectItem>
              <SelectItem value="zapatos">Zapatos</SelectItem>
              <SelectItem value="medias">Medias</SelectItem>
            </SelectContent>
          </Select>
          {errors.category && <p className="text-destructive text-sm">{errors.category}</p>}
        </div>
      </div>
      
      <div className="space-y-2">
        <Label>Imágenes del producto</Label>
        {formData.images.map((image, index) => (
          <div key={index} className="flex items-center gap-2">
            <Input
              type="text"
              value={image}
              onChange={(e) => handleImageChange(index, e.target.value)}
              placeholder="https://ejemplo.com/imagen.jpg"
              className={(errors.images && errors.images[index]) ? "border-destructive" : ""}
            />
            {formData.images.length > 1 && (
              <Button type="button" variant="ghost" size="icon" onClick={() => removeImageField(index)}>
                <Trash2 className="h-4 w-4 text-destructive" />
              </Button>
            )}
          </div>
        ))}
        {errors.images && errors.images.some(e => e) && !Array.isArray(errors.images) && (
          <p className="text-destructive text-sm">{errors.images}</p>
        )}
        {errors.images && Array.isArray(errors.images) && errors.images.map((err, idx) => err && (
          <p key={idx} className="text-destructive text-sm">{err}</p>
        ))}

        <Button type="button" variant="outline" size="sm" onClick={addImageField} className="gap-1">
          <PlusCircle className="h-4 w-4" />
          Añadir otra imagen
        </Button>
      </div>
      
      <div className="space-y-2">
        <Label htmlFor="stock">Stock disponible</Label>
        <Input
          id="stock"
          name="stock"
          type="number"
          value={formData.stock}
          onChange={handleChange}
          className={errors.stock ? "border-destructive" : ""}
          min="0"
        />
        {errors.stock && <p className="text-destructive text-sm">{errors.stock}</p>}
      </div>
      
      <Button type="submit" className="w-full">
        {buttonText}
      </Button>
    </form>
  );
};

export default ProductForm;
