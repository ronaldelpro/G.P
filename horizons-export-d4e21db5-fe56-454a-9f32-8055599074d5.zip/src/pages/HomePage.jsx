
import React from "react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import ProductCard from "@/components/ProductCard";
import CategoryCard from "@/components/CategoryCard";
import { useProducts } from "@/context/ProductContext";
import { motion } from "framer-motion";

const HomePage = () => {
  const { products } = useProducts();
  
  const featuredProducts = products.slice(0, 4);
  
  const categories = ["camisetas", "pantalonetas", "zapatos", "medias"];

  return (
    <div className="container py-8">
      <section className="relative rounded-lg overflow-hidden mb-16">
        <div className="hero-gradient text-white p-8 md:p-16 rounded-lg">
          <div className="max-w-2xl">
            <motion.h1 
              className="text-3xl md:text-5xl font-bold mb-4"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
            >
              Bienvenido a G.P.
            </motion.h1>
            <motion.p 
              className="text-lg md:text-xl mb-6 opacity-90"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.1 }}
            >
              Tu tienda deportiva de confianza. Encuentra las mejores prendas deportivas originales para tu estilo de vida activo.
            </motion.p>
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
            >
              <Link to="/products">
                <Button size="lg" className="bg-white text-primary hover:bg-white/90">
                  Ver todos los productos
                </Button>
              </Link>
            </motion.div>
          </div>
        </div>
        <div className="absolute inset-0 -z-10">
          <img  className="w-full h-full object-cover" alt="Fondo deportivo" src="https://images.unsplash.com/photo-1528656685602-17a25fe7abcd" />
        </div>
      </section>

      <section className="mb-16">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-bold">Categorías</h2>
          <Link to="/products" className="text-primary hover:underline">
            Ver todas
          </Link>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {categories.map((category) => (
            <CategoryCard key={category} category={category} />
          ))}
        </div>
      </section>

      <Separator className="my-12" />

      <section className="mb-16">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-bold">Productos destacados</h2>
          <Link to="/products" className="text-primary hover:underline">
            Ver todos
          </Link>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {featuredProducts.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      </section>

      <section className="mb-16">
        <div className="bg-muted rounded-lg p-8 relative overflow-hidden">
          <div className="relative z-10 max-w-xl">
            <h2 className="text-2xl md:text-3xl font-bold mb-4">¿Quieres vender tus productos?</h2>
            <p className="mb-6">
              Regístrate y comienza a vender tus prendas deportivas en nuestra plataforma. Alcanza a miles de clientes potenciales.
            </p>
            <Link to="/register">
              <Button>Comenzar a vender</Button>
            </Link>
          </div>
          <div className="absolute right-0 bottom-0 w-1/3 h-full opacity-20 md:opacity-100">
            <img  className="w-full h-full object-cover" alt="Vendedor deportivo" src="https://images.unsplash.com/photo-1694604339987-b57aa4865bdb" />
          </div>
        </div>
      </section>

      <section>
        <h2 className="text-2xl font-bold mb-6 text-center">Lo que dicen nuestros clientes</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <motion.div 
            className="bg-muted p-6 rounded-lg"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3 }}
          >
            <p className="italic mb-4">
              "Excelente calidad en las camisetas. Son originales y el envío fue muy rápido. Definitivamente volveré a comprar."
            </p>
            <p className="font-semibold">Carlos Rodríguez</p>
          </motion.div>
          <motion.div 
            className="bg-muted p-6 rounded-lg"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3, delay: 0.1 }}
          >
            <p className="italic mb-4">
              "Los zapatos deportivos que compré son increíbles. Muy cómodos y resistentes. El precio es justo por la calidad que ofrecen."
            </p>
            <p className="font-semibold">Ana Martínez</p>
          </motion.div>
          <motion.div 
            className="bg-muted p-6 rounded-lg"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3, delay: 0.2 }}
          >
            <p className="italic mb-4">
              "Proceso de compra muy sencillo y atención al cliente excepcional. Recomiendo G.P. a todos mis amigos."
            </p>
            <p className="font-semibold">Juan Pérez</p>
          </motion.div>
        </div>
      </section>
    </div>
  );
};

export default HomePage;
