
import React, { useState } from "react";
import { useParams, Link, useNavigate } from "react-router-dom";
import { useProducts } from "@/context/ProductContext";
import { useCart } from "@/context/CartContext";
import { useAuth } from "@/context/AuthContext";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { 
  ChevronLeft, 
  ShoppingCart, 
  Minus, 
  Plus, 
  Heart,
  Share2,
  ChevronRight,
  Image as ImageIcon
} from "lucide-react";
import { formatPrice } from "@/lib/utils";
import { motion } from "framer-motion";
import ProductCard from "@/components/ProductCard";

const ProductDetailPage = () => {
  const { id } = useParams();
  const { getProductById, products } = useProducts();
  const { addToCart } = useCart();
  const { currentUser } = useAuth();
  const navigate = useNavigate();
  
  const [quantity, setQuantity] = useState(1);
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  
  const product = getProductById(id);
  
  if (!product) {
    return (
      <div className="container py-16 text-center">
        <h1 className="text-2xl font-bold mb-4">Producto no encontrado</h1>
        <p className="mb-6">El producto que buscas no existe o ha sido eliminado.</p>
        <Link to="/products">
          <Button>Ver todos los productos</Button>
        </Link>
      </div>
    );
  }
  
  const productImages = product.images && product.images.length > 0 ? product.images : ["https://via.placeholder.com/600x600?text=No+Image"];
  
  const nextImage = () => {
    setCurrentImageIndex((prevIndex) => (prevIndex + 1) % productImages.length);
  };

  const prevImage = () => {
    setCurrentImageIndex((prevIndex) => (prevIndex - 1 + productImages.length) % productImages.length);
  };

  const selectImage = (index) => {
    setCurrentImageIndex(index);
  };
  
  const relatedProducts = products
    .filter(p => p.category === product.category && p.id !== product.id)
    .slice(0, 4);
  
  const decreaseQuantity = () => {
    if (quantity > 1) setQuantity(quantity - 1);
  };
  
  const increaseQuantity = () => {
    if (quantity < product.stock) setQuantity(quantity + 1);
  };
  
  const handleAddToCart = () => addToCart(product, quantity);
  
  const handleBuyNow = () => {
    addToCart(product, quantity);
    navigate("/cart");
  };

  return (
    <div className="container py-8">
      <Link to="/products">
        <Button variant="ghost" className="mb-6 pl-0">
          <ChevronLeft className="mr-2 h-4 w-4" />
          Volver a productos
        </Button>
      </Link>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 lg:gap-12 mb-16">
        <motion.div 
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.3 }}
          className="flex flex-col gap-4"
        >
          <div className="relative aspect-square rounded-lg overflow-hidden border">
            {productImages.map((imgSrc, index) => (
              <motion.img
                key={index}
                src={imgSrc}
                alt={`${product.name} - Imagen ${index + 1}`}
                className="absolute top-0 left-0 w-full h-full object-cover"
                initial={{ opacity: 0 }}
                animate={{ opacity: index === currentImageIndex ? 1 : 0 }}
                transition={{ duration: 0.3 }}
              />
            ))}
            {productImages.length === 0 && (
              <div className="w-full h-full bg-muted flex items-center justify-center">
                <ImageIcon className="h-16 w-16 text-muted-foreground" />
              </div>
            )}
            {productImages.length > 1 && (
              <>
                <Button 
                  variant="ghost" 
                  size="icon" 
                  onClick={prevImage} 
                  className="absolute left-2 top-1/2 -translate-y-1/2 bg-background/50 hover:bg-background/80"
                >
                  <ChevronLeft className="h-5 w-5" />
                </Button>
                <Button 
                  variant="ghost" 
                  size="icon" 
                  onClick={nextImage} 
                  className="absolute right-2 top-1/2 -translate-y-1/2 bg-background/50 hover:bg-background/80"
                >
                  <ChevronRight className="h-5 w-5" />
                </Button>
              </>
            )}
          </div>
          {productImages.length > 1 && (
            <div className="grid grid-cols-5 gap-2">
              {productImages.map((imgSrc, index) => (
                <button
                  key={index}
                  onClick={() => selectImage(index)}
                  className={`aspect-square rounded-md overflow-hidden border-2 ${
                    index === currentImageIndex ? "border-primary" : "border-transparent"
                  } hover:border-primary/50 transition-colors`}
                >
                  <img
                    src={imgSrc}
                    alt={`Thumbnail ${index + 1}`}
                    className="w-full h-full object-cover"
                  />
                </button>
              ))}
            </div>
          )}
        </motion.div>
        
        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.3 }}
          className="flex flex-col"
        >
          <h1 className="text-3xl font-bold mb-2">{product.name}</h1>
          <div className="text-2xl font-bold text-primary mb-4">{formatPrice(product.price)}</div>
          <p className="text-muted-foreground mb-6">{product.description}</p>
          
          <div className="mb-6">
            <div className="flex items-center mb-2">
              <span className="font-medium mr-2">Disponibilidad:</span>
              {product.stock > 0 ? (
                <span className="text-green-600">En stock ({product.stock} disponibles)</span>
              ) : (
                <span className="text-red-600">Agotado</span>
              )}
            </div>
            <div className="flex items-center">
              <span className="font-medium mr-2">Categoría:</span>
              <Link to={`/category/${product.category}`} className="text-primary hover:underline">
                {product.category.charAt(0).toUpperCase() + product.category.slice(1)}
              </Link>
            </div>
          </div>
          
          <Separator className="mb-6" />
          
          {product.stock > 0 && (
            <>
              <div className="flex items-center mb-6">
                <span className="font-medium mr-4">Cantidad:</span>
                <div className="flex items-center border rounded-md">
                  <Button variant="ghost" size="icon" onClick={decreaseQuantity} disabled={quantity <= 1}>
                    <Minus className="h-4 w-4" />
                  </Button>
                  <span className="w-12 text-center">{quantity}</span>
                  <Button variant="ghost" size="icon" onClick={increaseQuantity} disabled={quantity >= product.stock}>
                    <Plus className="h-4 w-4" />
                  </Button>
                </div>
              </div>
              
              <div className="flex flex-col sm:flex-row gap-4 mb-6">
                <Button className="flex-1 gap-2" onClick={handleAddToCart}>
                  <ShoppingCart className="h-4 w-4" />
                  Añadir al carrito
                </Button>
                <Button variant="secondary" className="flex-1" onClick={handleBuyNow}>
                  Comprar ahora
                </Button>
              </div>
            </>
          )}
          
          <div className="flex gap-4">
            <Button variant="outline" size="sm" className="gap-2">
              <Heart className="h-4 w-4" />
              Añadir a favoritos
            </Button>
            <Button variant="outline" size="sm" className="gap-2">
              <Share2 className="h-4 w-4" />
              Compartir
            </Button>
          </div>
          
          {currentUser && product.seller === currentUser.id && (
            <div className="mt-6 p-4 bg-muted rounded-lg">
              <p className="font-medium mb-2">Este es tu producto</p>
              <div className="flex gap-2">
                <Button variant="outline" size="sm" onClick={() => navigate(`/edit-product/${product.id}`)}>
                  Editar producto
                </Button>
              </div>
            </div>
          )}
        </motion.div>
      </div>
      
      {relatedProducts.length > 0 && (
        <div>
          <h2 className="text-2xl font-bold mb-6">Productos relacionados</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {relatedProducts.map((prod) => (
              <ProductCard key={prod.id} product={prod} />
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default ProductDetailPage;
