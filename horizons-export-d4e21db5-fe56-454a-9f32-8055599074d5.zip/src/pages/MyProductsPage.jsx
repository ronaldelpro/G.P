
import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useProducts } from "@/context/ProductContext";
import { useAuth } from "@/context/AuthContext";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Pencil, Trash2, Plus, Image as ImageIcon } from "lucide-react";
import { formatPrice } from "@/lib/utils";
import { motion } from "framer-motion";

const MyProductsPage = () => {
  const { currentUser } = useAuth();
  const { deleteProduct, getProductsByUser } = useProducts();
  const navigate = useNavigate();
  
  const [productToDelete, setProductToDelete] = useState(null);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  
  const myProducts = getProductsByUser(currentUser.id);
  
  const handleEdit = (productId) => {
    navigate(`/edit-product/${productId}`);
  };
  
  const openDeleteDialog = (product) => {
    setProductToDelete(product);
    setIsDeleteDialogOpen(true);
  };
  
  const confirmDelete = () => {
    if (productToDelete) {
      deleteProduct(productToDelete.id);
      setIsDeleteDialogOpen(false);
      setProductToDelete(null);
    }
  };
  
  return (
    <div className="container py-8">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-3xl font-bold">Mis productos</h1>
        <Button onClick={() => navigate("/add-product")} className="gap-2">
          <Plus className="h-4 w-4" />
          Añadir producto
        </Button>
      </div>
      
      {myProducts.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {myProducts.map((product) => {
            const displayImage = product.images && product.images.length > 0 ? product.images[0] : null;
            return (
              <motion.div
                key={product.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3 }}
              >
                <Card className="h-full flex flex-col">
                  <div className="aspect-square relative overflow-hidden border-b">
                    {displayImage ? (
                       <img  alt={product.name} class="w-full h-full object-cover" src="https://images.unsplash.com/photo-1702567855965-176e97304a4b" />
                    ) : (
                      <div className="w-full h-full bg-muted flex items-center justify-center">
                        <ImageIcon className="h-16 w-16 text-muted-foreground" />
                      </div>
                    )}
                    {product.stock <= 0 && (
                      <div className="absolute inset-0 bg-black/60 flex items-center justify-center">
                        <span className="text-white font-bold text-lg">Agotado</span>
                      </div>
                    )}
                  </div>
                  <CardHeader className="p-4 pb-0">
                    <Link to={`/product/${product.id}`} className="font-semibold text-lg hover:underline">
                      {product.name}
                    </Link>
                    <div className="font-bold text-lg">{formatPrice(product.price)}</div>
                  </CardHeader>
                  <CardContent className="p-4 pt-2 flex-grow">
                    <p className="text-sm text-muted-foreground mb-2">
                      Categoría: {product.category}
                    </p>
                    <p className="text-sm text-muted-foreground">
                      Stock: {product.stock} unidades
                    </p>
                  </CardContent>
                  <CardFooter className="p-4 pt-0 flex gap-2">
                    <Button 
                      variant="outline" 
                      className="flex-1 gap-2"
                      onClick={() => handleEdit(product.id)}
                    >
                      <Pencil className="h-4 w-4" />
                      Editar
                    </Button>
                    <Button 
                      variant="outline" 
                      className="flex-1 gap-2 text-destructive hover:text-destructive"
                      onClick={() => openDeleteDialog(product)}
                    >
                      <Trash2 className="h-4 w-4" />
                      Eliminar
                    </Button>
                  </CardFooter>
                </Card>
              </motion.div>
            );
          })}
        </div>
      ) : (
        <div className="text-center py-12 bg-muted rounded-lg">
          <h3 className="text-xl font-medium mb-2">No tienes productos</h3>
          <p className="text-muted-foreground mb-4">
            Comienza a vender añadiendo tu primer producto
          </p>
          <Button onClick={() => navigate("/add-product")}>
            Añadir producto
          </Button>
        </div>
      )}
      
      <Dialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>¿Estás seguro?</DialogTitle>
            <DialogDescription>
              Esta acción no se puede deshacer. Se eliminará permanentemente el producto{" "}
              <span className="font-semibold">{productToDelete?.name}</span>.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsDeleteDialogOpen(false)}>
              Cancelar
            </Button>
            <Button variant="destructive" onClick={confirmDelete}>
              Eliminar
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default MyProductsPage;
