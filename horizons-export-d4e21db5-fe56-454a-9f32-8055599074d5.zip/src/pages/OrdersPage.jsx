
import React from "react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { formatPrice } from "@/lib/utils";
import { motion } from "framer-motion";
import { ShoppingBag } from "lucide-react";

// Datos de ejemplo para pedidos
const mockOrders = [
  {
    id: "ORD-001",
    date: "2023-10-15",
    status: "Entregado",
    total: 235000,
    items: [
      { id: "camiseta-1", name: "Camiseta Oficial Real Madrid", quantity: 1, price: 120000 },
      { id: "medias-1", name: "Medias Deportivas Puma", quantity: 3, price: 35000 }
    ]
  },
  {
    id: "ORD-002",
    date: "2023-10-10",
    status: "En camino",
    total: 180000,
    items: [
      { id: "zapatos-1", name: "Zapatos de Fútbol Adidas Predator", quantity: 1, price: 180000 }
    ]
  }
];

const OrdersPage = () => {
  return (
    <div className="container py-8">
      <h1 className="text-3xl font-bold mb-6">Mis pedidos</h1>
      
      {mockOrders.length > 0 ? (
        <div className="space-y-6">
          {mockOrders.map((order, index) => (
            <motion.div
              key={order.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, delay: index * 0.1 }}
            >
              <Card>
                <CardHeader>
                  <div className="flex justify-between items-start">
                    <div>
                      <CardTitle>Pedido #{order.id}</CardTitle>
                      <CardDescription>
                        Realizado el {new Date(order.date).toLocaleDateString()}
                      </CardDescription>
                    </div>
                    <div className="text-right">
                      <span className={`inline-block px-3 py-1 rounded-full text-sm font-medium ${
                        order.status === "Entregado" 
                          ? "bg-green-100 text-green-800" 
                          : "bg-blue-100 text-blue-800"
                      }`}>
                        {order.status}
                      </span>
                      <p className="mt-1 font-bold">{formatPrice(order.total)}</p>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <h3 className="font-medium mb-2">Productos</h3>
                  <div className="space-y-3">
                    {order.items.map((item) => (
                      <div key={item.id} className="flex justify-between">
                        <div className="flex-1">
                          <p className="font-medium">{item.name}</p>
                          <p className="text-sm text-muted-foreground">
                            Cantidad: {item.quantity}
                          </p>
                        </div>
                        <p className="font-medium">{formatPrice(item.price * item.quantity)}</p>
                      </div>
                    ))}
                  </div>
                </CardContent>
                <Separator />
                <CardFooter className="justify-between py-4">
                  <Button variant="outline" size="sm">
                    Ver detalles
                  </Button>
                  <Button variant="outline" size="sm">
                    Seguimiento
                  </Button>
                </CardFooter>
              </Card>
            </motion.div>
          ))}
        </div>
      ) : (
        <div className="text-center py-16">
          <ShoppingBag className="mx-auto h-16 w-16 text-muted-foreground mb-4" />
          <h3 className="text-xl font-medium mb-2">No tienes pedidos</h3>
          <p className="text-muted-foreground mb-6">
            Aún no has realizado ningún pedido
          </p>
          <Link to="/products">
            <Button>Explorar productos</Button>
          </Link>
        </div>
      )}
    </div>
  );
};

export default OrdersPage;
