
import React, { useState } from "react";
import { useProducts } from "@/context/ProductContext";
import ProductCard from "@/components/ProductCard";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { Search, Filter } from "lucide-react";
import { motion } from "framer-motion";

const ProductsPage = () => {
  const { products } = useProducts();
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("");
  const [sortBy, setSortBy] = useState("featured");
  const [priceRange, setPriceRange] = useState({ min: "", max: "" });
  const [showFilters, setShowFilters] = useState(false);

  // Filtrar productos
  const filteredProducts = products.filter(product => {
    const matchesSearch = product.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          product.description.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory ? product.category === selectedCategory : true;
    const matchesPriceMin = priceRange.min ? product.price >= Number(priceRange.min) : true;
    const matchesPriceMax = priceRange.max ? product.price <= Number(priceRange.max) : true;
    
    return matchesSearch && matchesCategory && matchesPriceMin && matchesPriceMax;
  });

  // Ordenar productos
  const sortedProducts = [...filteredProducts].sort((a, b) => {
    switch (sortBy) {
      case "price-asc":
        return a.price - b.price;
      case "price-desc":
        return b.price - a.price;
      case "name-asc":
        return a.name.localeCompare(b.name);
      case "name-desc":
        return b.name.localeCompare(a.name);
      default:
        return 0; // featured - mantener el orden original
    }
  });

  const handleSearch = (e) => {
    e.preventDefault();
    // La búsqueda ya se aplica en tiempo real, este formulario es solo para la UX
  };

  const handlePriceChange = (e) => {
    const { name, value } = e.target;
    setPriceRange(prev => ({ ...prev, [name]: value }));
  };

  const resetFilters = () => {
    setSearchTerm("");
    setSelectedCategory("");
    setSortBy("featured");
    setPriceRange({ min: "", max: "" });
  };

  const toggleFilters = () => {
    setShowFilters(!showFilters);
  };

  return (
    <div className="container py-8">
      <h1 className="text-3xl font-bold mb-6">Todos los productos</h1>
      
      <div className="flex flex-col lg:flex-row gap-8">
        {/* Filtros para móvil */}
        <div className="lg:hidden mb-4">
          <Button 
            variant="outline" 
            className="w-full flex items-center justify-center gap-2"
            onClick={toggleFilters}
          >
            <Filter className="h-4 w-4" />
            {showFilters ? "Ocultar filtros" : "Mostrar filtros"}
          </Button>
        </div>
        
        {/* Sidebar de filtros */}
        <motion.aside 
          className={`w-full lg:w-64 space-y-6 ${showFilters ? 'block' : 'hidden lg:block'}`}
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.3 }}
        >
          <div>
            <h3 className="font-medium mb-3">Buscar</h3>
            <form onSubmit={handleSearch} className="relative">
              <Input
                type="search"
                placeholder="Buscar productos..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pr-10"
              />
              <Button type="submit" size="icon" variant="ghost" className="absolute right-0 top-0">
                <Search className="h-4 w-4" />
              </Button>
            </form>
          </div>
          
          <Separator />
          
          <div>
            <h3 className="font-medium mb-3">Categoría</h3>
            <Select value={selectedCategory} onValueChange={setSelectedCategory}>
              <SelectTrigger>
                <SelectValue placeholder="Todas las categorías" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="">Todas las categorías</SelectItem>
                <SelectItem value="camisetas">Camisetas</SelectItem>
                <SelectItem value="pantalonetas">Pantalonetas</SelectItem>
                <SelectItem value="zapatos">Zapatos</SelectItem>
                <SelectItem value="medias">Medias</SelectItem>
              </SelectContent>
            </Select>
          </div>
          
          <Separator />
          
          <div>
            <h3 className="font-medium mb-3">Rango de precio</h3>
            <div className="grid grid-cols-2 gap-2">
              <div>
                <Label htmlFor="min" className="text-xs">Mínimo</Label>
                <Input
                  id="min"
                  name="min"
                  type="number"
                  placeholder="Min"
                  value={priceRange.min}
                  onChange={handlePriceChange}
                  min="0"
                />
              </div>
              <div>
                <Label htmlFor="max" className="text-xs">Máximo</Label>
                <Input
                  id="max"
                  name="max"
                  type="number"
                  placeholder="Max"
                  value={priceRange.max}
                  onChange={handlePriceChange}
                  min="0"
                />
              </div>
            </div>
          </div>
          
          <Separator />
          
          <div>
            <h3 className="font-medium mb-3">Ordenar por</h3>
            <Select value={sortBy} onValueChange={setSortBy}>
              <SelectTrigger>
                <SelectValue placeholder="Destacados" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="featured">Destacados</SelectItem>
                <SelectItem value="price-asc">Precio: menor a mayor</SelectItem>
                <SelectItem value="price-desc">Precio: mayor a menor</SelectItem>
                <SelectItem value="name-asc">Nombre: A-Z</SelectItem>
                <SelectItem value="name-desc">Nombre: Z-A</SelectItem>
              </SelectContent>
            </Select>
          </div>
          
          <Button variant="outline" className="w-full" onClick={resetFilters}>
            Restablecer filtros
          </Button>
        </motion.aside>
        
        {/* Lista de productos */}
        <div className="flex-1">
          {sortedProducts.length > 0 ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {sortedProducts.map((product) => (
                <ProductCard key={product.id} product={product} />
              ))}
            </div>
          ) : (
            <div className="text-center py-12">
              <h3 className="text-xl font-medium mb-2">No se encontraron productos</h3>
              <p className="text-muted-foreground mb-4">
                Intenta con otros filtros o términos de búsqueda
              </p>
              <Button variant="outline" onClick={resetFilters}>
                Restablecer filtros
              </Button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default ProductsPage;
