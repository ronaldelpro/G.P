
import React from "react";
import { useParams, Link } from "react-router-dom";
import { useProducts } from "@/context/ProductContext";
import ProductCard from "@/components/ProductCard";
import { Button } from "@/components/ui/button";
import { ChevronLeft } from "lucide-react";
import { motion } from "framer-motion";

const categoryNames = {
  camisetas: "Camisetas",
  pantalonetas: "Pantalonetas",
  zapatos: "Zapatos",
  medias: "Medias"
};

const categoryDescriptions = {
  camisetas: "Encuentra las mejores camisetas deportivas de tus equipos favoritos. Calidad y originalidad garantizada.",
  pantalonetas: "Pantalonetas deportivas cómodas y duraderas para tus actividades físicas. Variedad de estilos y marcas.",
  zapatos: "Calzado deportivo y de fútbol de las mejores marcas. Comodidad y rendimiento para tus pies.",
  medias: "Medias deportivas de alta calidad para complementar tu equipamiento. Durabilidad y confort garantizados."
};

const CategoryPage = () => {
  const { category } = useParams();
  const { getProductsByCategory } = useProducts();
  
  const products = getProductsByCategory(category);
  const categoryName = categoryNames[category] || "Categoría";
  const categoryDescription = categoryDescriptions[category] || "";

  return (
    <div className="container py-8">
      <div className="mb-8">
        <Link to="/products">
          <Button variant="ghost" className="mb-4 pl-0">
            <ChevronLeft className="mr-2 h-4 w-4" />
            Volver a productos
          </Button>
        </Link>
        
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3 }}
        >
          <h1 className="text-3xl font-bold mb-2">{categoryName}</h1>
          <p className="text-muted-foreground max-w-3xl">{categoryDescription}</p>
        </motion.div>
      </div>
      
      {products.length > 0 ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {products.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      ) : (
        <div className="text-center py-12">
          <h3 className="text-xl font-medium mb-2">No hay productos en esta categoría</h3>
          <p className="text-muted-foreground mb-4">
            Vuelve más tarde o explora otras categorías
          </p>
          <Link to="/products">
            <Button>Ver todos los productos</Button>
          </Link>
        </div>
      )}
    </div>
  );
};

export default CategoryPage;
