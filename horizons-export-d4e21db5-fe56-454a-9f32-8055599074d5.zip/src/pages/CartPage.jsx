
import React from "react";
import { Link, useNavigate } from "react-router-dom";
import { useCart } from "@/context/CartContext";
import { useAuth } from "@/context/AuthContext";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { Trash2, Plus, Minus, ShoppingCart, ArrowRight } from "lucide-react";
import { formatPrice } from "@/lib/utils";
import { motion } from "framer-motion";
import { useToast } from "@/components/ui/use-toast";

const CartPage = () => {
  const { cartItems, removeFromCart, updateQuantity, clearCart, getCartTotal } = useCart();
  const { currentUser } = useAuth();
  const navigate = useNavigate();
  const { toast } = useToast();
  
  const handleCheckout = () => {
    if (!currentUser) {
      toast({
        title: "Inicia sesión para continuar",
        description: "Debes iniciar sesión para completar tu compra",
        variant: "destructive",
      });
      navigate("/login", { state: { from: "/cart" } });
      return;
    }
    
    // Aquí iría la lógica para procesar el pedido
    toast({
      title: "Pedido realizado",
      description: "Tu pedido ha sido procesado correctamente",
    });
    clearCart();
    navigate("/orders");
  };
  
  if (cartItems.length === 0) {
    return (
      <div className="container py-16 text-center">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.3 }}
        >
          <ShoppingCart className="mx-auto h-16 w-16 text-muted-foreground mb-4" />
          <h1 className="text-2xl font-bold mb-4">Tu carrito está vacío</h1>
          <p className="text-muted-foreground mb-6">
            Parece que aún no has añadido productos a tu carrito
          </p>
          <Link to="/products">
            <Button>Explorar productos</Button>
          </Link>
        </motion.div>
      </div>
    );
  }
  
  return (
    <div className="container py-8">
      <h1 className="text-3xl font-bold mb-6">Tu carrito</h1>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Lista de productos */}
        <div className="lg:col-span-2">
          <div className="bg-card rounded-lg border shadow-sm">
            <div className="p-6">
              <div className="flex justify-between items-center mb-4">
                <h2 className="text-xl font-semibold">Productos ({cartItems.length})</h2>
                <Button 
                  variant="ghost" 
                  size="sm" 
                  className="text-muted-foreground"
                  onClick={clearCart}
                >
                  Vaciar carrito
                </Button>
              </div>
              
              <Separator className="mb-6" />
              
              <div className="space-y-6">
                {cartItems.map((item) => (
                  <motion.div 
                    key={item.id}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.2 }}
                    className="flex flex-col sm:flex-row gap-4"
                  >
                    <div className="w-full sm:w-24 h-24 rounded-md overflow-hidden flex-shrink-0">
                      <img 
                        src={item.image} 
                        alt={item.name} 
                        className="w-full h-full object-cover"
                      />
                    </div>
                    
                    <div className="flex-1">
                      <div className="flex justify-between">
                        <Link to={`/product/${item.id}`} className="font-medium hover:underline">
                          {item.name}
                        </Link>
                        <div className="font-bold">
                          {formatPrice(item.price * item.quantity)}
                        </div>
                      </div>
                      
                      <p className="text-sm text-muted-foreground mb-2">
                        {formatPrice(item.price)} por unidad
                      </p>
                      
                      <div className="flex justify-between items-center">
                        <div className="flex items-center border rounded-md">
                          <Button 
                            variant="ghost" 
                            size="icon" 
                            className="h-8 w-8"
                            onClick={() => updateQuantity(item.id, item.quantity - 1)}
                            disabled={item.quantity <= 1}
                          >
                            <Minus className="h-3 w-3" />
                          </Button>
                          <span className="w-8 text-center text-sm">{item.quantity}</span>
                          <Button 
                            variant="ghost" 
                            size="icon" 
                            className="h-8 w-8"
                            onClick={() => updateQuantity(item.id, item.quantity + 1)}
                          >
                            <Plus className="h-3 w-3" />
                          </Button>
                        </div>
                        
                        <Button 
                          variant="ghost" 
                          size="icon" 
                          className="text-muted-foreground hover:text-destructive"
                          onClick={() => removeFromCart(item.id)}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  </motion.div>
                ))}
              </div>
            </div>
          </div>
        </div>
        
        {/* Resumen del pedido */}
        <div>
          <div className="bg-card rounded-lg border shadow-sm p-6 sticky top-20">
            <h2 className="text-xl font-semibold mb-4">Resumen del pedido</h2>
            
            <Separator className="mb-4" />
            
            <div className="space-y-2 mb-4">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Subtotal</span>
                <span>{formatPrice(getCartTotal())}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Envío</span>
                <span>Gratis</span>
              </div>
            </div>
            
            <Separator className="mb-4" />
            
            <div className="flex justify-between font-bold text-lg mb-6">
              <span>Total</span>
              <span>{formatPrice(getCartTotal())}</span>
            </div>
            
            <Button 
              className="w-full gap-2" 
              size="lg"
              onClick={handleCheckout}
            >
              Finalizar compra
              <ArrowRight className="h-4 w-4" />
            </Button>
            
            <p className="text-xs text-muted-foreground text-center mt-4">
              Al finalizar la compra, aceptas nuestros términos y condiciones
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CartPage;
