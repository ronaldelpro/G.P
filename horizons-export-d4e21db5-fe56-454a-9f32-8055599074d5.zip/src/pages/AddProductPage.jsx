
import React from "react";
import { useNavigate } from "react-router-dom";
import { useProducts } from "@/context/ProductContext";
import { useAuth } from "@/context/AuthContext";
import { Button } from "@/components/ui/button";
import { ChevronLeft } from "lucide-react";
import ProductForm from "@/components/ProductForm";

const AddProductPage = () => {
  const { addProduct } = useProducts();
  const { currentUser } = useAuth();
  const navigate = useNavigate();
  
  const handleSubmit = (productData) => {
    const productWithSeller = {
      ...productData,
      seller: currentUser.id,
      images: productData.images.filter(img => img.trim() !== "") // Asegurar que las imágenes no estén vacías
    };
    
    addProduct(productWithSeller);
    navigate("/my-products");
  };
  
  return (
    <div className="container py-8 max-w-2xl">
      <Button 
        variant="ghost" 
        className="mb-6 pl-0"
        onClick={() => navigate("/my-products")}
      >
        <ChevronLeft className="mr-2 h-4 w-4" />
        Volver a mis productos
      </Button>
      
      <h1 className="text-3xl font-bold mb-6">Añadir nuevo producto</h1>
      
      <ProductForm 
        onSubmit={handleSubmit}
        buttonText="Crear producto"
        initialData={{ images: [""] }}
      />
    </div>
  );
};

export default AddProductPage;
