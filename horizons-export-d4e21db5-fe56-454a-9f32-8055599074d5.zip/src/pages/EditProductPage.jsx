
import React from "react";
import { useParams, useNavigate } from "react-router-dom";
import { useProducts } from "@/context/ProductContext";
import { Button } from "@/components/ui/button";
import { ChevronLeft } from "lucide-react";
import ProductForm from "@/components/ProductForm";

const EditProductPage = () => {
  const { id } = useParams();
  const { getProductById, updateProduct } = useProducts();
  const navigate = useNavigate();
  
  const product = getProductById(id);
  
  if (!product) {
    return (
      <div className="container py-16 text-center">
        <h1 className="text-2xl font-bold mb-4">Producto no encontrado</h1>
        <p className="mb-6">El producto que intentas editar no existe o ha sido eliminado.</p>
        <Button onClick={() => navigate("/my-products")}>
          Volver a mis productos
        </Button>
      </div>
    );
  }
  
  const handleSubmit = (productData) => {
    const updatedData = {
      ...productData,
      images: productData.images.filter(img => img.trim() !== "")
    };
    updateProduct(id, updatedData);
    navigate("/my-products");
  };
  
  return (
    <div className="container py-8 max-w-2xl">
      <Button 
        variant="ghost" 
        className="mb-6 pl-0"
        onClick={() => navigate("/my-products")}
      >
        <ChevronLeft className="mr-2 h-4 w-4" />
        Volver a mis productos
      </Button>
      
      <h1 className="text-3xl font-bold mb-6">Editar producto</h1>
      
      <ProductForm 
        initialData={{...product, images: product.images && product.images.length > 0 ? product.images : [""]}}
        onSubmit={handleSubmit}
        buttonText="Actualizar producto"
      />
    </div>
  );
};

export default EditProductPage;
