
import React, { useEffect, useState } from "react";
import { useLocation, Link } from "react-router-dom";
import { useProducts } from "@/context/ProductContext";
import ProductCard from "@/components/ProductCard";
import { Button } from "@/components/ui/button";
import { ChevronLeft } from "lucide-react";

const SearchPage = () => {
  const location = useLocation();
  const { searchProducts } = useProducts();
  const [searchResults, setSearchResults] = useState([]);
  const [searchQuery, setSearchQuery] = useState("");
  
  useEffect(() => {
    const query = new URLSearchParams(location.search).get("q");
    if (query) {
      setSearchQuery(query);
      const results = searchProducts(query);
      setSearchResults(results);
    }
  }, [location.search, searchProducts]);
  
  return (
    <div className="container py-8">
      <Link to="/products">
        <Button variant="ghost" className="mb-6 pl-0">
          <ChevronLeft className="mr-2 h-4 w-4" />
          Volver a productos
        </Button>
      </Link>
      
      <h1 className="text-3xl font-bold mb-2">Resultados de búsqueda</h1>
      <p className="text-muted-foreground mb-6">
        {searchResults.length} resultados para "{searchQuery}"
      </p>
      
      {searchResults.length > 0 ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {searchResults.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      ) : (
        <div className="text-center py-12 bg-muted rounded-lg">
          <h3 className="text-xl font-medium mb-2">No se encontraron resultados</h3>
          <p className="text-muted-foreground mb-4">
            No hay productos que coincidan con tu búsqueda
          </p>
          <Link to="/products">
            <Button>Ver todos los productos</Button>
          </Link>
        </div>
      )}
    </div>
  );
};

export default SearchPage;
