
import React, { createContext, useContext, useState, useEffect } from "react";
import { getFromLocalStorage, saveToLocalStorage, generateId } from "@/lib/utils";
import { useToast } from "@/components/ui/use-toast";

const ProductContext = createContext();

export const useProducts = () => {
  return useContext(ProductContext);
};

const initialProducts = [
  {
    id: "camiseta-1",
    name: "Camiseta Oficial Real Madrid",
    description: "Camiseta oficial del Real Madrid temporada 2024/2025",
    price: 120000,
    category: "camisetas",
    images: [
      "https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
      "https://images.unsplash.com/photo-1628305277893-4723db9107ee?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
      "https://images.unsplash.com/photo-1552066344-2464c1135c32?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80"
    ],
    stock: 15,
    seller: "admin"
  },
  {
    id: "camiseta-2",
    name: "Camiseta Barcelona FC",
    description: "Camiseta oficial del FC Barcelona temporada actual",
    price: 115000,
    category: "camisetas",
    images: [
      "https://images.unsplash.com/photo-1577212017308-55f90828eae6?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
      "https://images.unsplash.com/photo-1619288988933-a0e2d3872e84?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80"
    ],
    stock: 10,
    seller: "admin"
  },
  {
    id: "pantaloneta-1",
    name: "Pantaloneta Deportiva Nike",
    description: "Pantaloneta deportiva Nike Dri-FIT para entrenamiento",
    price: 65000,
    category: "pantalonetas",
    images: [
      "https://images.unsplash.com/photo-1562183241-b937e95585b6?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80"
    ],
    stock: 20,
    seller: "admin"
  },
  {
    id: "zapatos-1",
    name: "Zapatos de Fútbol Adidas Predator",
    description: "Zapatos de fútbol Adidas Predator para césped natural",
    price: 180000,
    category: "zapatos",
    images: [
      "https://images.unsplash.com/photo-1511886929837-354984c0605b?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
      "https://images.unsplash.com/photo-1552066344-2464c1135c32?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80"
    ],
    stock: 8,
    seller: "admin"
  },
  {
    id: "zapatos-2",
    name: "Zapatos Deportivos Nike Air",
    description: "Zapatos deportivos Nike Air para running y entrenamiento",
    price: 210000,
    category: "zapatos",
    images: [
      "https://images.unsplash.com/photo-1542291026-7eec264c27ff?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
      "https://images.unsplash.com/photo-1491553691912-b2242f76a7c5?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80"
    ],
    stock: 12,
    seller: "admin"
  },
  {
    id: "medias-1",
    name: "Medias Deportivas Puma",
    description: "Pack de 3 pares de medias deportivas Puma",
    price: 35000,
    category: "medias",
    images: [
      "https://images.unsplash.com/photo-1586350977771-b3b0abd50c82?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80"
    ],
    stock: 30,
    seller: "admin"
  }
];

export const ProductProvider = ({ children }) => {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();

  useEffect(() => {
    const savedProducts = getFromLocalStorage("products");
    if (savedProducts && savedProducts.length > 0) {
      // Asegurarse de que todos los productos tengan el campo 'images'
      const normalizedProducts = savedProducts.map(p => ({
        ...p,
        images: p.images && p.images.length > 0 ? p.images : (p.image ? [p.image] : [])
      }));
      setProducts(normalizedProducts);
    } else {
      const normalizedInitialProducts = initialProducts.map(p => ({
        ...p,
        images: p.images && p.images.length > 0 ? p.images : (p.image ? [p.image] : [])
      }));
      setProducts(normalizedInitialProducts);
      saveToLocalStorage("products", normalizedInitialProducts);
    }
    setLoading(false);
  }, []);

  const addProduct = (product) => {
    const newProduct = {
      ...product,
      id: generateId(),
      createdAt: new Date().toISOString(),
      images: product.images && product.images.length > 0 ? product.images : [],
    };
    
    setProducts(prevProducts => {
      const updatedProducts = [...prevProducts, newProduct];
      saveToLocalStorage("products", updatedProducts);
      return updatedProducts;
    });
    
    toast({
      title: "Producto añadido",
      description: `${product.name} ha sido añadido correctamente`,
    });
    
    return newProduct;
  };

  const updateProduct = (id, updatedProductData) => {
    setProducts(prevProducts => {
      const updatedProducts = prevProducts.map(product => 
        product.id === id ? { ...product, ...updatedProductData, images: updatedProductData.images && updatedProductData.images.length > 0 ? updatedProductData.images : product.images } : product
      );
      saveToLocalStorage("products", updatedProducts);
      return updatedProducts;
    });
    
    toast({
      title: "Producto actualizado",
      description: `${updatedProductData.name} ha sido actualizado correctamente`,
    });
  };

  const deleteProduct = (id) => {
    setProducts(prevProducts => {
      const updatedProducts = prevProducts.filter(product => product.id !== id);
      saveToLocalStorage("products", updatedProducts);
      return updatedProducts;
    });
    
    toast({
      title: "Producto eliminado",
      description: "El producto ha sido eliminado correctamente",
    });
  };

  const getProductsByCategory = (category) => {
    return products.filter(product => product.category === category);
  };

  const getProductById = (id) => {
    return products.find(product => product.id === id);
  };

  const getProductsByUser = (userId) => {
    return products.filter(product => product.seller === userId);
  };

  const searchProducts = (query) => {
    const searchTerm = query.toLowerCase();
    return products.filter(product => 
      product.name.toLowerCase().includes(searchTerm) || 
      product.description.toLowerCase().includes(searchTerm)
    );
  };

  const value = {
    products,
    loading,
    addProduct,
    updateProduct,
    deleteProduct,
    getProductsByCategory,
    getProductById,
    getProductsByUser,
    searchProducts
  };

  return (
    <ProductContext.Provider value={value}>
      {children}
    </ProductContext.Provider>
  );
};
