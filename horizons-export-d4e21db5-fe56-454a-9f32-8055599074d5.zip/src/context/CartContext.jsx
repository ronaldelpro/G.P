
import React, { createContext, useContext, useState, useEffect } from "react";
import { getFromLocalStorage, saveToLocalStorage } from "@/lib/utils";
import { useToast } from "@/components/ui/use-toast";

const CartContext = createContext();

export const useCart = () => {
  return useContext(CartContext);
};

export const CartProvider = ({ children }) => {
  const [cartItems, setCartItems] = useState([]);
  const { toast } = useToast();

  useEffect(() => {
    const savedCart = getFromLocalStorage("cart", []);
    setCartItems(savedCart);
  }, []);

  const saveCart = (items) => {
    setCartItems(items);
    saveToLocalStorage("cart", items);
  };

  const addToCart = (product, quantity = 1) => {
    setCartItems(prevItems => {
      const existingItem = prevItems.find(item => item.id === product.id);
      
      let newItems;
      if (existingItem) {
        newItems = prevItems.map(item => 
          item.id === product.id 
            ? { ...item, quantity: item.quantity + quantity } 
            : item
        );
      } else {
        newItems = [...prevItems, { ...product, quantity }];
      }
      
      saveToLocalStorage("cart", newItems);
      return newItems;
    });
    
    toast({
      title: "Producto añadido",
      description: `${product.name} se ha añadido al carrito`,
    });
  };

  const removeFromCart = (productId) => {
    setCartItems(prevItems => {
      const newItems = prevItems.filter(item => item.id !== productId);
      saveToLocalStorage("cart", newItems);
      return newItems;
    });
    
    toast({
      title: "Producto eliminado",
      description: "El producto se ha eliminado del carrito",
    });
  };

  const updateQuantity = (productId, quantity) => {
    if (quantity < 1) return;
    
    setCartItems(prevItems => {
      const newItems = prevItems.map(item => 
        item.id === productId ? { ...item, quantity } : item
      );
      saveToLocalStorage("cart", newItems);
      return newItems;
    });
  };

  const clearCart = () => {
    setCartItems([]);
    saveToLocalStorage("cart", []);
    
    toast({
      title: "Carrito vacío",
      description: "Se han eliminado todos los productos del carrito",
    });
  };

  const getCartTotal = () => {
    return cartItems.reduce((total, item) => total + (item.price * item.quantity), 0);
  };

  const getCartCount = () => {
    return cartItems.reduce((count, item) => count + item.quantity, 0);
  };

  const value = {
    cartItems,
    addToCart,
    removeFromCart,
    updateQuantity,
    clearCart,
    getCartTotal,
    getCartCount
  };

  return (
    <CartContext.Provider value={value}>
      {children}
    </CartContext.Provider>
  );
};
