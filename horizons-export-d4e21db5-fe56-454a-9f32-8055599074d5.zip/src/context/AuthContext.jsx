
import React, { createContext, useContext, useState, useEffect } from "react";
import { getFromLocalStorage, saveToLocalStorage } from "@/lib/utils";
import { useToast } from "@/components/ui/use-toast";

const AuthContext = createContext();

export const useAuth = () => {
  return useContext(AuthContext);
};

export const AuthProvider = ({ children }) => {
  const [currentUser, setCurrentUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();

  useEffect(() => {
    const user = getFromLocalStorage("currentUser");
    if (user) {
      setCurrentUser(user);
    }
    setLoading(false);
  }, []);

  const signup = (email, password, name) => {
    try {
      // Verificar si el usuario ya existe
      const users = getFromLocalStorage("users", []);
      const existingUser = users.find(user => user.email === email);
      
      if (existingUser) {
        throw new Error("El correo electrónico ya está registrado");
      }
      
      // Crear nuevo usuario
      const newUser = {
        id: Date.now().toString(),
        email,
        password,
        name,
        role: "user",
        createdAt: new Date().toISOString()
      };
      
      // Guardar usuario en la lista de usuarios
      saveToLocalStorage("users", [...users, newUser]);
      
      // Iniciar sesión automáticamente
      setCurrentUser(newUser);
      saveToLocalStorage("currentUser", newUser);
      
      toast({
        title: "Registro exitoso",
        description: "¡Bienvenido a The Original!",
      });
      
      return newUser;
    } catch (error) {
      toast({
        title: "Error en el registro",
        description: error.message,
        variant: "destructive",
      });
      throw error;
    }
  };

  const login = (email, password) => {
    try {
      const users = getFromLocalStorage("users", []);
      const user = users.find(
        user => user.email === email && user.password === password
      );
      
      if (!user) {
        throw new Error("Correo electrónico o contraseña incorrectos");
      }
      
      setCurrentUser(user);
      saveToLocalStorage("currentUser", user);
      
      toast({
        title: "Inicio de sesión exitoso",
        description: `¡Bienvenido de nuevo, ${user.name}!`,
      });
      
      return user;
    } catch (error) {
      toast({
        title: "Error de inicio de sesión",
        description: error.message,
        variant: "destructive",
      });
      throw error;
    }
  };

  const logout = () => {
    setCurrentUser(null);
    localStorage.removeItem("currentUser");
    toast({
      title: "Sesión cerrada",
      description: "Has cerrado sesión correctamente",
    });
  };

  const value = {
    currentUser,
    signup,
    login,
    logout,
    isAdmin: currentUser?.role === "admin",
  };

  return (
    <AuthContext.Provider value={value}>
      {!loading && children}
    </AuthContext.Provider>
  );
};
